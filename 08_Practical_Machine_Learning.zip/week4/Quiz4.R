
##1
library(ElemStatLearn)
data(vowel.train)
data(vowel.test)

head(vowel.train)

vowel.train$y <- as.factor(vowel.train$y)
vowel.test$y <- as.factor(vowel.test$y)

library(caret)
set.seed(33833)
fit1 <- train(y~., data = vowel.train, method = "rf")
fit2 <- train(y~., data = vowel.train, method = "gbm", verbose = FALSE)

pred1 <- predict(fit1, newdata =vowel.test ) 
pred2 <- predict(fit2, newdata =vowel.test ) 

cm1 <- confusionMatrix(pred1, vowel.test$y)
cm2 <- confusionMatrix(pred2, vowel.test$y)
cm_agree <- confusionMatrix(pred1, pred2)

cm1$overall
cm2$overall
cm_agree$overall

# RF Accuracy = 0.6082
# GBM Accuracy = 0.5152
# Agreement Accuracy = 0.6361


##2
library(caret)
library(gbm)
set.seed(3433)
library(AppliedPredictiveModeling)
data(AlzheimerDisease)
adData = data.frame(diagnosis,predictors)
inTrain = createDataPartition(adData$diagnosis, p = 3/4)[[1]]
training = adData[ inTrain,]
testing = adData[-inTrain,]

set.seed(62433)
fit_rf <- train(diagnosis~., data = training, method = "rf")
fit_gbm <- train(diagnosis~., data = training, method = "gbm", verbose = FALSE)
fit_lda <- train(diagnosis~., data = training, method = "lda", verbose = FALSE)  
pred_rf <- predict(fit_rf, newdata = testing)
pred_gbm <- predict(fit_gbm, newdata = testing)
pred_lda <- predict(fit_lda, newdata = testing)
confusionMatrix(pred_rf, testing$diagnosis)$overall
confusionMatrix(pred_gbm, testing$diagnosis)$overall
confusionMatrix(pred_lda, testing$diagnosis)$overall

stackdata <- data.frame(testing$diagnosis,pred_rf, pred_gbm, pred_lda)
fit_stack <- train(testing.diagnosis~., data = stackdata, method = "rf")
pred_stack <- predict(fit_stack, newdata = stackdata)
confusionMatrix(pred_stack, stackdata$testing.diagnosis)$overall

#Stacked Accuracy: 0.80 is better than all three other methods  (correct Ans: Stacked Accuracy: 0.80 is better than random forests and lda and the same as boosting.)


##3
set.seed(3523)
library(AppliedPredictiveModeling)
data(concrete)
inTrain = createDataPartition(concrete$CompressiveStrength, p = 3/4)[[1]]
training = concrete[ inTrain,]
testing = concrete[-inTrain,]

set.seed(233)
fit <- train(CompressiveStrength~., data = training, method = "lasso")
plot(fit$finalModel, xvar = "penalty", use.color = TRUE)

#Cement 


##4
library(lubridate) # For year() function below
dat = read.csv("~/Data/gaData.csv")
training = dat[year(dat$date) < 2012,]
testing = dat[(year(dat$date)) > 2011,]
tstrain = ts(training$visitsTumblr)

fit <- bats(tstrain)
fc <- forecast(fit, level = 95, h=nrow(testing))
plot(fc)
lower95 <- fc$lower
upper95 <- fc$upper
table( (testing$visitsTumblr> lower95) & (testing$visitsTumblr<upper95) )

## FALSE  TRUE 
##     9   226
# 96%


##5
set.seed(3523)
library(AppliedPredictiveModeling)
data(concrete)
inTrain = createDataPartition(concrete$CompressiveStrength, p = 3/4)[[1]]
training = concrete[ inTrain,]
testing = concrete[-inTrain,]

set.seed(325)
library(e1071)
fit <- svm(CompressiveStrength~. , data = training)
pred <- predict(fit, newdata = testing)
accuracy(pred, concrete$CompressiveStrength)

# OR

error = pred - testing$CompressiveStrength
mse <- sqrt(mean(error^2))
mse

#6.71





