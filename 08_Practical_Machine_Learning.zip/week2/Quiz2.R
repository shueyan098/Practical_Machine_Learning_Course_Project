## 1. 
library(AppliedPredictiveModeling)
data(AlzheimerDisease)

library(caret)
adData = data.frame(diagnosis,predictors)
trainIndex = createDataPartition(diagnosis, p = 0.50,list=FALSE)
training = adData[trainIndex,]
testing = adData[-trainIndex,]


## 2.
library(AppliedPredictiveModeling)
data(concrete)
library(caret)
set.seed(1000)
inTrain = createDataPartition(mixtures$CompressiveStrength, p = 3/4)[[1]]
training = mixtures[ inTrain,]
testing = mixtures[-inTrain,]

library(Hmisc)
summary(training)
cutCS <- cut2(training$CompressiveStrength, g =4)
p1 <- qplot(cutCS, Cement, data=training, fill=cutCS,geom=c("boxplot"))
p1
p2 <- qplot(cutCS, FlyAsh, data=training, fill=cutCS,geom=c("boxplot"))
p2
p3 <- qplot(cutCS, Age, data=training, fill=cutCS,geom=c("boxplot"))
p3

# There is a non-random pattern in the plot of the outcome versus index that 
# does not appear to be perfectly explained by any predictor suggesting a variable may be missing.


## 3.
library(AppliedPredictiveModeling)
data(concrete)
library(caret)
set.seed(1000)
inTrain = createDataPartition(mixtures$CompressiveStrength, p = 3/4)[[1]]
training = mixtures[ inTrain,]
testing = mixtures[-inTrain,]

hist(training$Superplasticizer)
# the variable is skewed

hist(log(training$Superplasticizer))
# sysmetric 

# Wrong???
# Why would that be a poor choice for this variable?
# The log transform does not reduce the skewness of the non-zero values of SuperPlasticizer.

# Ans: There are values of zero so when you take the log() transform those values will be -Inf.


## 4.
library(caret)
library(AppliedPredictiveModeling)
set.seed(3433)
data(AlzheimerDisease)
adData = data.frame(diagnosis,predictors)
inTrain = createDataPartition(adData$diagnosis, p = 3/4)[[1]]
training = adData[ inTrain,]
testing = adData[-inTrain,]

trainingIL <- training[,grep("^IL", names(training))]
procTrain <- preProcess(trainingIL, method = "pca", thresh = 0.9 )
procTrain
# PCA needed 9 components to capture 90 percent of the variance


## 5.
library(caret)
library(AppliedPredictiveModeling)
set.seed(3433)
data(AlzheimerDisease)
adData = data.frame(diagnosis,predictors)
inTrain = createDataPartition(adData$diagnosis, p = 3/4)[[1]]
training = adData[ inTrain,]
testing = adData[-inTrain,]

trainingIL <- training[,grep("^IL|diagnosis", names(training))]
testingIL <- testing[,grep("^IL|diagnosis", names(testing))]

# non-PCA
model <- train(diagnosis ~ ., data = trainingIL, method = "glm")
predict_model <- predict(model, newdata= testingIL)
matrix_model <- confusionMatrix(predict_model, testingIL$diagnosis)
matrix_model$overall[1]
#  Accuracy : 0.6463

# PCA
modelPCA <- train(diagnosis ~., data = trainingIL, method = "glm", preProcess = "pca",trControl=trainControl(preProcOptions=list(thresh=0.8)))
matrix_modelPCA <- confusionMatrix(testingIL$diagnosis, predict(modelPCA, testingIL))
matrix_modelPCA$overall[1]
# Accuracy : 0.7195












