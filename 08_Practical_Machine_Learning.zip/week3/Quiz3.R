
#### 1.
library(AppliedPredictiveModeling)
data(segmentationOriginal)
library(caret)

#(1)
segOri <- segmentationOriginal
inTrain = createDataPartition(segOri$Case, p = 3/4,list=FALSE)
training = segOri[inTrain,]
testing = segOri[-inTrain,]

#(2)
set.seed(125)
modFit <- train(Case~., data=training, method="rpart")

#(3)
modFit$finalModel

library(rattle) 
library(rpart.plot)
fancyRpartPlot(modFit$finalModel)

#plot(modFit$finalModel, uniform = TRUE, main="Classification Tree")
#text(modFit$finalModel, use.n = TRUE, all = TRUE, cex=0.8)

# Based on the decision tree, the model prediction is:
# a. PS
# b. WS
# c. PS
# d. Not possible to predict


#### 2.
# If K is small in a K-fold cross validation is the bias in the estimate of out-of-sample (test set) accuracy smaller or bigger? 
# If K is small is the variance in the estimate of out-of-sample (test set) accuracy smaller or bigger. 
# Is K large or small in leave one out cross validation?

# Ans: The bias is larger and the variance is smaller. 
# Ans: Under leave one out cross validation K is equal to the sample size.


#### 3.
library(pgmm)
data(olive)
olive = olive[,-1]
newdata = as.data.frame(t(colMeans(olive)))

# set.seed(125)
modFit <- train(Area~., data=olive, method="rpart")
modFit$finalModel

plot(modFit$finalModel, uniform = TRUE, main="Classification Tree")
text(modFit$finalModel, use.n = TRUE, all = TRUE, cex=0.8)

predict(modFit, newdata = newdata)
# ans: 2.783282


#### 4.
library(ElemStatLearn)
data(SAheart)
set.seed(8484)
train = sample(1:dim(SAheart)[1],size=dim(SAheart)[1]/2,replace=F)
trainSA = SAheart[train,]
testSA = SAheart[-train,]
missClass = function(values,prediction){sum(((prediction > 0.5)*1) != values)/length(values)}


set.seed(13234)
modFit <- train(chd~age+alcohol+obesity+tobacco+typea+ldl, data=trainSA, method = "glm", family = "binomial")

#misclassification rate on test set:
missClass(testSA$chd, predict(modFit, newdata = testSA ))
# 0.3116883

#misclassification rate on train set:
missClass(trainSA$chd, predict(modFit, newdata = trainSA ))
# 0.2727273


#### 5.
library(ElemStatLearn)
data(vowel.train)
data(vowel.test)

vowel.train$y <- as.factor(vowel.train$y)
vowel.test$y <- as.factor(vowel.test$y)
set.seed(33833)
library(randomForest)
modFit <- randomForest(y~., data= vowel.train)

varImp(modFit)  ## importance of variables
order(varImp(modFit), decreasing = T)

# ans: 2  1  5  6  8  4  9  3  7 10

# the order of the variables is: 
# x.2, x.1, x.5, x.6, x.8, x.4, x.9, x.3, x.7, x.10














